#ifndef OTANETWORKDEVICE_H
    #define OTANETWORKDEVICE_H

    #define WIFI_NETWORK_NAME ""
    #define WIFI_NETWORK_PASSWORD ""
    #define BROKER_IP ""
    #define DEVICE_NAME ""

    class OTANetworkDevice;

    #include "OTA.h"
    #include "MQTT.h"
    #include "WebServer.h"

    class OTANetworkDevice{
        private:
            String WiFiNetworkName;
            String WiFiNetworkPassword;
            String brokerIP;
            String name;
        public:
            void setup();
            void handle();
            
            void setWiFiNetworkName(String);
            void setWiFiNetworkPassword(String);
            void setBrokerIP(String);
            void setName(String);

            String getName() const;
    };
#endif