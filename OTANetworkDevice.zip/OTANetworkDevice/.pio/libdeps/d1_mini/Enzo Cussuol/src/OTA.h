#ifndef OTA_H
    #define OTA_H

    #include <ArduinoOTA.h>

    void setupOTA();
    void handleOTA();
#endif