#ifndef CONFIG_H
    #define CONFIG_H

    #define WIFI_NETWORK_NAME ""
    #define WIFI_NETWORK_PASSWORD ""
    #define BROKER_IP ""

    extern long MY_DEVICE_ID;
#endif