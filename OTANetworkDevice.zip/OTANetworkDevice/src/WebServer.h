#ifndef WEBSERVER_H
    #define WEBSERVER_H
    
    #include "OTANetworkDevice.h"

    void setupWebServer();
    void handleWebServer(OTANetworkDevice*);
#endif